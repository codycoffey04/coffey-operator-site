
Netlify Deploy Instructions
---------------------------
1. Log in to Netlify and click "Add new site" → "Deploy manually".
2. Drag and drop everything in this ZIP (HTML pages, logo.jpg, index.html, _redirects, README.txt) into the upload window.
3. Netlify will deploy instantly. The _redirects file forces unknown routes to index.html for cleaner 404 handling.
4. Test a city page by visiting /[ZIP].html (e.g., /30024.html).
